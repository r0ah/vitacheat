PSVITACHEAT Z05版
主要更新：

支持365系统
增加内存浏览页面查看eboot模块seg信息（右摇杆上推切换显示隐藏）
代码格式增加$B200
其他小调整

下载
链接: https://pan.baidu.com/s/1FaLCiOZlqVy-bjrbXy9IGg 密码: e362

MD5 (vitacheat.skprx) = e119d0bc75ee303729a47c0ae0b4ea69

SHA1(vitacheat.skprx) = 0faf50ac2b9105b40395004687a1df9efa0fbda0

MD5 (vitacheat.suprx) = eba38655b19782ae7c408b825af48c4a

SHA1(vitacheat.suprx) = 50367137ce9e5d326706edab11edbcef7d81aa2c

安装
与Z04版本一样，将vitacheat.suprx复制到ux0:vitacheat目录下，vitacheat.skprx复制到ur0:vitacheat目录下，config.txt里添加：

*KERNEL
ur0:vitacheat/vitacheat.skprx
$B200格式
$B200 0000000X 00000000
X=0或1，0代表seg0，1代表seg1
B200后面跟着的代码格式全部变成相对偏移，base由程序获得（也就是内存页面显示的segX信息）
主要用于解决不同版本地址发生偏移的情况。

举例：伊苏树海（PCSH00181）的mai版跟vitamin版的地址就有偏移

# PCSH00181 伊苏树海-1.00-MAI5 by dask

_V0 金钱MAX
$A100 810C6872 0000BF00
seg0:81000000-811F9188

# PCSH00181 伊苏树海-1.00-vitamin by dask

_V0 金钱MAX
$A100 810C68D2 0000BF00
seg0:81000060-811F91E8

可以用B格式的码解决上面这个问题

# PCSH00181 伊苏树海-1.00 by dask

_V0 金钱MAX
$B200 00000000 00000000
$A100 000C6872 0000BF00
上面这个是seg0的例子，seg1的应用可以自己去尝试忍者龙剑传Σ2+，使用$B200可以做到欧中版（PCSB00294）和港中版（PCSG00157）代码通用

Support or Contact
有问题请联系finalcheat@gmail.com
