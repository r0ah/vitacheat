#include <vitasdk.h>
#include <taihen.h>


/**
 * 
 *  00. module name: ffx_phyreApp 
 *  path: ux0:/app/PCSH00042/ffx_phyreApp.self
 *  vaddr: 0x81000000
 *  memsz: 0x62af50
 *  vaddr: 0x8162b000
 *  memsz: 0x1dd283c
 *
 **/

typedef struct vitacheatinfo
{
    char* english_name;
    char* simplified_name;
    char* traditional_name;
    char* japanese_name;
    uintptr_t func;
} vitacheatinfo;



int get_ffx_phyreApp_module(tai_module_info_t* pt_module_info)
{
    pt_module_info->size = sizeof(tai_module_info_t);
    return taiGetModuleInfo("ffx_phyreApp", pt_module_info);
}


/**
 *
 * Code Author: Dask
 * Source: http://www.speedfly.cn/19985.html
 *
 * _V0 Max Gil After Using    =>    _V0 Max Gil After Using 
 * $A100 811CD8C4 0000BF00    =>    $B200 00000000 00000000
 *                            =>    $A100 001CD8C4 0000BF00
 *
 **/

static SceUID mgauUID = -1;

static void max_gil_after_using(int lock)
{
    if (lock)
    {
        if (mgauUID > 0)
        {
            return;
        }
        tai_module_info_t module_info;
        int ret = get_ffx_phyreApp_module(&module_info);
        if (ret != 0)
        {
            return;
        }

        const uint32_t offset = 0x1CD8C4;
        const uint16_t value = 0xBF00;

        tai_offset_args_t args;
        args.size = sizeof(args);
        args.modid = module_info.modid;
        args.segidx = 0;
        args.offset = offset;
        args.source = &value;
        args.source_size = sizeof(value);
        mgauUID = taiInjectDataForUser(&args);
    }
    else
    {
        if (mgauUID > 0)
        {
            taiInjectRelease(mgauUID);
            mgauUID = -1;
        }
    }
}


/**
 *
 * Code Author: Dask
 * Source: http://www.speedfly.cn/19985.html
 *
 * _V0 All Item 99            =>    _V0 All Item 99
 * $4101 8262A76C 00002000    =>    $B200 00000001 00000000
 * $006F 00000002 00000001    =>    $4101 00FFF76C 00002000
 * $4001 8262A96C 00000063    =>    $006F 00000002 00000001
 * $006F 00000001 00000000    =>    $4001 00FFF96C 00000063
 *                            =>    $006F 00000001 00000000
 *
 **/

static void all_item_99(int lock)
{
    if (lock)
    {
        tai_module_info_t module_info;
        int ret = get_ffx_phyreApp_module(&module_info);
        if (ret != 0)
        {
            return;
        }
        SceKernelModuleInfo kernel_module_info = {0};
        ret = sceKernelGetModuleInfo(module_info.modid, &kernel_module_info);
        if (ret != 0)
        {
            return;
        }
        SceKernelSegmentInfo* seg1 = &(kernel_module_info.segments[1]);
        uint16_t value1 = 0x2000;
        uint32_t offset = 0xFFF76C;
        for (int i = 0; i < 0x6F; ++i)
        {
            void* addr = seg1->vaddr + offset + i * 0x2;
            *(uint16_t*)addr = value1;
            value1 += 0x1;
        }
        const uint8_t value2 = 0x63;
        offset = 0xFFF96C;
        for (int i = 0; i < 0x6F; ++i)
        {
            void* addr = seg1->vaddr + offset + i;
            *(uint8_t*)addr = value2;
        }
    }
}


/**
 *
 * CHEAT LIST
 *
 **/
static vitacheatinfo info[] = {
    { .english_name = "Max Gil After Using", .simplified_name = "金钱变动后MAX", .traditional_name = "金錢變動后MAX", .japanese_name = "Max Gil After Using", .func = (uintptr_t)max_gil_after_using },
    { .english_name = "All Item 99", .simplified_name = "全道具99个", .traditional_name = "全道具99個", .japanese_name = "All Item 99", .func = (uintptr_t)all_item_99 },
    { .english_name = NULL, .simplified_name = NULL, .traditional_name = NULL, .japanese_name = NULL, .func = 0 },
};


vitacheatinfo* getvcinfo()
{
    return info;
}


int module_start(SceSize args, void *argp)
{
    sceClibPrintf("PCSH00042 suprx test by FinalCheat\n");

    return SCE_KERNEL_START_SUCCESS;
}



int module_stop(SceSize args, void* argp)
{
    return SCE_KERNEL_STOP_SUCCESS;
}


void _start() __attribute__ ((weak, alias ("module_start")));
